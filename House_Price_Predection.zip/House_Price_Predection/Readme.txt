* From code directory use command
	npm install 

  it will install angular modules required.

* Later use command 
	ng serve -o
  
  to run the angular code and host it in localhost

* From src/assets/server run command 
	py server.py 

  to start server to perdection file 